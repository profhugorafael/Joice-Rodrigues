from interpretador_arquivo import processaInstancias

processaInstancias('instancia1.txt')